# Anonymous repository-completion v1 artifact

This supplementary package accompanies the double-anonymous submission. It contains the frozen
protocol, executable six-task fixture and hidden oracles, the complete 288-call records, both model
audits, the independent analysis, and tests for the research harness.

Run the offline harness tests from the package root with:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -S -m unittest \
  scripts.test_repository_completion_probe \
  scripts.test_research_metrics scripts.test_small_model_pilot_preflight
```

Paths, prototype/package names, and temporary-directory prefixes in the copied text have been
replaced to preserve double anonymity. This creates a disclosure-safe derivative: cryptographic
hashes retained in the freeze records identify the immutable pre-sanitization originals and are
not expected to match the renamed derivative byte-for-byte. Counts, labels, model outputs,
schedule indices, statistical results, and model digests are unchanged. No model weights or
provider credentials are included.
